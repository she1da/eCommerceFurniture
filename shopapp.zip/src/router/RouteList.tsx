import React from "react";
import { createBrowserRouter, RouteObject } from "react-router-dom";
import Home from "../components/pages/Home";
import About from "../components/pages/About";
import Login from "../components/pages/Login";
import Register from "../components/pages/Register";

const routes: RouteObject[] = [
    {
        path: "/",
        element: <Home />,
    },
    {
        path: "/about",
        element: <About />,
    },
    {
        path: "/login",
        element: <Login />,
    },
    {
        path: "/register",
        element: <Register />,
    },
];

const router = createBrowserRouter(routes);

export default router;
